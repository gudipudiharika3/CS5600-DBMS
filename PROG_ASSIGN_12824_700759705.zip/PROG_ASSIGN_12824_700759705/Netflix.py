from json import dumps

import pymongo
from flask import Flask, request, Response
from bson.json_util import dumps, loads

app = Flask(__name__)

try:
    # Replace the connection string with your MongoDB Atlas connection string
    mongo_uri = "mongodb+srv://gudipudiharika392002:admin@cluster0.nl0l7ka.mongodb.net/?retryWrites=true&w=majority"

    mongo = pymongo.MongoClient(mongo_uri)
    db = mongo.get_database("database")

    # This line is not needed, as you don't need to manually trigger an exception
    # mongo.server_info()
except Exception as e:
    print(f"Error - could not connect to the database: {e}")


@app.route('/netflix', methods=['POST'])
def insert_document():
    try:
        data = request.get_json()  # Assuming you're sending JSON data in the request

        # Insert the data into the collection
        result = db.netflix.insert_one(data)

        response = Response(f"New Record added: {result}", status=201, mimetype='application/json')
    except Exception as ex:
        response = Response(f"Insert New Record Error!!: {ex}", status=500, mimetype='application/json')
    return response


@app.route('/netflix', methods=['GET'])
def get_all_documents():
    try:
        results = db.netflix.find()
        response = Response(dumps(results), status=200, mimetype='application/json')
    except Exception as ex:
        response = Response(f"Search records Error!!: {ex}", status=500, mimetype='application/json')
    return response


@app.route('/netflix/<string:title>', methods=['GET'])
def get_document(title):
    try:
        data = {"title": title}
        results = db.netflix.find(data)
        response = Response(dumps(results), status=200, mimetype='application/json')
    except Exception as ex:
        response = Response(f"Search records Error!!: {ex}", status=500, mimetype='application/json')
    return response


@app.route('/netflix/<string:title>', methods=['PATCH'])
def update_document(title):
    try:
        key = {"title": title}
        data = request.get_json()
        update_record = {"$set": data}
        result = db.netflix.update_one(key, update_record)
        response = Response(f"Record updated", status=201, mimetype='application/json')
    except Exception as ex:
        response = Response(f"Record update Error!!: {ex}", status=500, mimetype='application/json')
    return response


@app.route('/netflix/<string:title>', methods=['DELETE'])
def delete(title):
    try:
        data = {"title": title}
        result = db.netflix.delete_one(data)
        response = Response(f"Record deleted", status=201, mimetype='application/json')
    except Exception as ex:
        response = Response(f"Record delete Error!!: {ex}", status=500, mimetype='application/json')
    return response


if __name__ == '__main__':
    app.run(debug=True)
